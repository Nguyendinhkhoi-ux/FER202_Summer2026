import React from 'react';
import QuizApp from './Lab3/QuizApp';

function App() {
  return (
    <QuizApp />
  );
}

export default App;


